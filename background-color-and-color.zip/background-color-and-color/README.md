# Background-color and color 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/qBwXBad](https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/qBwXBad).

